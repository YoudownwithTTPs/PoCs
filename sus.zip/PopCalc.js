var app = new ActiveXObject("Shell.Application");
var ppa = "calc.exe";
app.ShellExecute(ppa,"","","","1");